microlight.js
=============

*microlight.js* is a tiny library (2.2k minified) which improves
 readability of code snippets by highlighting, for any programming
 language, without attaching additional language packages or styles:

![preview]
(http://asvd.github.io/microlight/microlight-preview-big.png)

For demos and usage guide, refer to https://asvd.github.io/microlight

--

Follow me on twitter: https://twitter.com/asvd0

